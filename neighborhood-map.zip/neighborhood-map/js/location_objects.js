var Location = function (data) {
    this.name = data.name;
    this.description: "Beautiful theater with decent movie selection - free popcorn on weekdays!";
    this.checkins: null;
    this.long: 37.811539;
    this.lat: -122.247356;
}

var locations = [];

var placesList = [],
    locations.forEach (function(model) {
        placesList.push(new Location(model));
    });